package com.example.postgres.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.postgres.Entity.EmployeeEntity;

    @Repository
	public interface EmployeeRepository extends CrudRepository<EmployeeEntity, Integer>{

	}



